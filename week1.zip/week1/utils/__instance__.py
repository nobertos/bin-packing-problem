from typing import List
MAX_CAPACITY = 50
INPUT_ITEMS: List[int] = [35, 35, 34, 34, 34, 33, 33, 33, 32, 31, 31, 30, 30, 29, 28, 28, 28, 27, 26, 26, 26, 26,
                          25, 25, 22, 22, 21, 20, 18, 18, 16, 16, 16, 16, 16, 13, 13, 13, 12, 11, 11, 10, 10, 9, 9, 7, 7, 7, 7, 5]
#


print(f"len(INPUT_ITEMS): {len(INPUT_ITEMS)}")
