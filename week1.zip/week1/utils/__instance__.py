MAX_CAPACITY = 50
INPUT_ITEMS = [35, 35, 34, 34, 34, 33, 33, 33, 32, 31, 31, 30, 30, 29, 28, 28, 28, 27, 26, 26, 26, 26,
               25, 25, 22, 22, 21, ]
#


print(f"len(INPUT_ITEMS): {len(INPUT_ITEMS)}")
